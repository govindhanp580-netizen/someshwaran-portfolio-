Someshwaran G Portfolio Website

Files:
- index.html
- style.css
- script.js
- profile.jpg

Open index.html in Chrome to view the website.
To publish it online, upload these files to GitHub Pages, Netlify, or Vercel.
